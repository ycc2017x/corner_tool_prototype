 $(function() {
	var availableTags = [
 	"Tableau",
 	"Alteryx",
 	"Server Knowledge",
 	];
	$("#D_SSelect").autocomplete({
		source: availableTags
	});
  });
