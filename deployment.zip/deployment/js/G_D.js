 $(function() {
	var availableTags = [
 	"Storyboarding simulations",
 	"HTML/CSS",
 	"Data visualization",
 	"Storyboarding videos",
 	"Motion graphic build",
 	"Brand/Logo design",
 	"Printed material design",
 	"User interface design",
 	"Photoshop",
 	"Illustrator",
 	"InDesign",
 	];
	$("#G_DSelect").autocomplete({
		source: availableTags
	});
  });
